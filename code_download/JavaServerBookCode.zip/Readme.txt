This download is being provided as a learning aid to the book

  Java Server Side Programming: The Conceptual Foundation

subject to the license terms as found in the file License.txt.

The downloaded files are organized in three folders:

1)  Support.  Readers are strongly encouraged to use the material in this folder in writing
    MVOWS for learning purposes.  The material in this folder is meant to reduce focus
    on string processing and such - tasks that are not directly relevant to understanding
    Java server side programming.

2)  Listings.  This contains the text of the various listings in the book, provided for
    ease of copy and paste.  If time and effort-level permit, this material should be
    typed from scratch, or as a language teacher might say "write this in your own words!"

    But if time and effort-level do not permit, this material can be copied and pasted
    in writing and understanding MVOWS.

3)  Solutions.  This contais full solutions to the tasks presented in the book.  Readers
    are encouraged to not use or look at the full solutions, unless they are very much
    pressed in terms of the time and effort-level they can bring to this learning task.

    These are the "answers in the back of the book".  For best results, compare with
    your own work, AFTER you have finished that work entirely on your own.
