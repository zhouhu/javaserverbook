package myapps;

import java.io.*;
import java.util.*;

public class ContentTypeMyWeblet extends mvows.MyWeblet
{
  public void doRequest( String resource, String queryString,
              HashMap<String,String> parameters, PrintWriter out )
  {
    setContentType( "text/plain" );

    out.println( "<HTML>");
    out.println( "<BODY>");
    out.println( "<H2>Hello, World</H2>" );
    out.println("Hello from My First MyWeblet");
    out.println( "</BODY>");
    out.println( "</HTML>");
  }
}
