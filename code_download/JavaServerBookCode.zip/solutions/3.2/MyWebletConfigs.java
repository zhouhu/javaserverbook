package mvows;

public class MyWebletConfigs
{
  String url;
  Class cls;

  public MyWebletConfigs( String url, Class cls )
  {
    this.url = url;
    this.cls = cls;
  }

  static MyWebletConfigs[] myWebletConfigs = new MyWebletConfigs[]
  {
    new MyWebletConfigs( "/HelloWorld", myapps.HelloWorldMyWeblet.class ),
    new MyWebletConfigs( "/RedirectTest", myapps.SendRedirectMyWeblet.class ),
    new MyWebletConfigs( "/ErrorTest", myapps.SendErrorMyWeblet.class ),
    new MyWebletConfigs( "/ContentTypeTest", myapps.ContentTypeMyWeblet.class ),
  };
}
