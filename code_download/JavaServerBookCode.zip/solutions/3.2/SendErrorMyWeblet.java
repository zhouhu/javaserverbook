package myapps;

import java.io.*;
import java.util.*;

public class SendErrorMyWeblet extends mvows.MyWeblet
{
  public void doRequest( String resource, String queryString,
              HashMap<String,String> parameters, PrintWriter out )
  {
      setError( 501, "Server Error" );
  }
}
