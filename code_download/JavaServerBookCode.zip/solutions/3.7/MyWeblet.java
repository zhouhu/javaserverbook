package mvows;

import java.io.*;
import java.util.*;

public abstract class MyWeblet
{
  static int sessionCookieId = 1;
  static Object sessionCookieLock = new Object();

  static Hashtable<String,MyWebletSession> sessionMap =
      new Hashtable<String,MyWebletSession>();

  String redirect = null;
  String contentType = null;
  int error = 0;
  String errDesc = null;

  HashMap<String,String> requestCookies = null;
  HashMap<String,String> responseCookies = new HashMap<String,String>();

  // Override this method to process the request
  public abstract void doRequest(
    String resource,                     // The URL, minus query string
    String queryString,                  // query string or null
    HashMap<String,String> parameters,   // Parsed parameters
    PrintWriter out                      // The output from the method
  );

  // Call this method to set content-type, default being text/html
  protected void setContentType(String ctype)
  {
      contentType = ctype;
  }

  // Call this method to send back an error.
  protected void setError(int errorCode, String description)
  {
    error = errorCode;
    errDesc = description;
  }

  // Call this method to tell the browser to
  // go to a different URL instead
  protected void sendRedirect( String newUrl )
  {
      redirect = newUrl;
  }

  public String getRequestCookie( String cookieName )
  {
      return requestCookies.get( cookieName );
  }
      
  public void setResponseCookie( String cookieName, String cookieValue )
  {
      responseCookies.put( cookieName, cookieValue );
  }

  protected MyWebletSession getSession()
  {
    // First, check to see if we received the session cookie.

    String sessionCookie =
        getRequestCookie( "mwsessionid" );

    if ( sessionCookie == null )
    {
      // The browser doesn't have a cookie, give it one.

      int id;
      // Make up a cookie.
      synchronized (sessionCookieLock)
      {
        // make sure the id's are incremented
        // with thread safety

        id = sessionCookieId++;
      }
      sessionCookie = String.valueOf( id );

      // We just need any unique string for the id.

      setResponseCookie( "mwsessionid", sessionCookie );

      // Add the new cookie as an outgoing cookie
    }

    MyWebletSession session = sessionMap.get( sessionCookie );
    if ( session == null )
    {
      // Instantiate a session, put it in sessionMap
      session = new MyWebletSession();
      sessionMap.put( sessionCookie, session );
    }

    session.lastUsed = System.currentTimeMillis();

    return session;
  }

}
