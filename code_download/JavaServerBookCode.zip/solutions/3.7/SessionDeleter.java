package mvows;

import java.util.*;

public class SessionDeleter implements Runnable
{
    public void run()
    {
        for (;;)
        {
            try {
                Thread.sleep( 10000L ); // Sleep 10 seconds
            } catch (InterruptedException ex) {}

            long expirationTime = System.currentTimeMillis() -
                               120000;  // Now - 2 minutes
            Enumeration<String> keys = MyWeblet.sessionMap.keys();
            while ( keys.hasMoreElements())
            {
                String key = keys.nextElement();
                MyWebletSession session = MyWeblet.sessionMap.get( key );
                if ( session.lastUsed < expirationTime )
                {
                    // Not been used for expiration duration, delete
                    System.out.println("Deleting session " + key );
                    MyWeblet.sessionMap.remove( key );
                }
            }
        }
    }
}
