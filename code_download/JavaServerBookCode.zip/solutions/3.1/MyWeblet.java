package mvows;

import java.io.*;
import java.util.*;

public abstract class MyWeblet
{
  // Override this method to process the request
  public abstract void doRequest(
    String resource,                     // The URL, minus query string
    String queryString,                  // query string or null
    HashMap<String,String> parameters,   // Parsed parameters
    PrintWriter out                      // The output from the method
  );

  // Call this method to set content-type, default being text/html
  protected void setContentType(String contentType)
  {
  }

  // Call this method to send back an error.
  protected void setError(int errorCode, String description)
  {
  }

  // Call this method to tell the browser to
  // go to a different URL instead
  protected void sendRedirect( String newUrl )
  {
  }
      
}
