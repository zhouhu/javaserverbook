package mvows;

import java.io.*;
import java.util.*;

public class MyWebletProcessor
{
  void processMyWeblet( Class cls, PrintWriter outputWriter )
  {
    try {
      Object instance = cls.newInstance();
          // This makes a new object of class 'cls'

      MyWeblet myWeblet = (MyWeblet) instance;
         // The class 'cls' subclasses mvows.MyWeblet,
         // therefore we can cast the object down

      ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
      PrintWriter out = new PrintWriter( byteArray );

      // For now, let's ignore the other parameters
      // to "doRequest" except "out"

       myWeblet.doRequest( null, null, null, out );

      // When "doRequest" returns, the output is in
      // the ByteArray "byteArray"
 
      // Send the default headers
      outputWriter.println("HTTP/1.0 200 OK" );
      outputWriter.println("Content-Type: text/html" );
      outputWriter.println(); // End headers with empty line

      // Send content

      out.flush();  // Make sure all output is in 'byteArray'

      outputWriter.println( byteArray.toString());
                  
    } catch (Exception ex)
    {
      ex.printStackTrace();
    }

    try {
      // Make sure the connection is closed in any case.
      outputWriter.close(); 
    } catch (Exception ex)
    {
    }
  }
}
