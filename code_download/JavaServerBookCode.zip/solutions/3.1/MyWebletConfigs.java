package mvows;

public class MyWebletConfigs
{
  String url;
  Class cls;

  public MyWebletConfigs( String url, Class cls )
  {
    this.url = url;
    this.cls = cls;
  }

  static MyWebletConfigs[] myWebletConfigs = new MyWebletConfigs[]
  {
    // Add one MyWebLet per line

    // e.g.

    new MyWebletConfigs( "/HelloWorld", myapps.HelloWorldMyWeblet.class ),
  };
}
