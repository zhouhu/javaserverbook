package mvows;

import java.net.*;
import java.io.*;

public class ServerInstance extends Thread
{

    Socket socket;

    public ServerInstance(Socket s)
    {
        socket = s;
    }

    public void run()
    {
        try {
            InputStream inputStream = socket.getInputStream();
            BufferedReader inputReader =
                new BufferedReader( new InputStreamReader( inputStream ));
            OutputStream outputStream = socket.getOutputStream();
            PrintWriter outputWriter =
                new PrintWriter(
                    new OutputStreamWriter( outputStream ));
            for (;;)
            {
                String line = inputReader.readLine();
                System.out.println( line );
            }

        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
