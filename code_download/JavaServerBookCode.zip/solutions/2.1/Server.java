package mvows;

import java.net.*;
import java.io.*;

public class Server
{
    public static void main(String[] args) throws Exception
    {
        System.setProperty("line.separator", "\r\n");
        ServerSocket server = new ServerSocket( 80 );
        for (;;)
        {
            System.out.println("Waiting for client connection");
            Socket socket = server.accept();
            System.out.println("Have client connection, launching thread");
            new ServerInstance( socket ).start();
        }
    }
}
