package mvows;

import java.net.*;
import java.io.*;

public class ServerInstance extends Thread
{

    Socket socket;

    public ServerInstance(Socket s)
    {
        socket = s;
    }

    public void run()
    {
        try {
          // Get the input/output as usual
          InputStream inputStream =
                  socket.getInputStream();
          BufferedReader inputReader =
            new BufferedReader(
               new InputStreamReader( inputStream ));
          OutputStream outputStream =
            socket.getOutputStream();
          PrintWriter outputWriter =
            new PrintWriter(
                new OutputStreamWriter( outputStream ));
   
          // Get the request line separately from the rest of the headers
          String requestLine = inputReader.readLine();
          System.out.println("Request line = " + requestLine);

          // Now read until the empty line, discard the header lines

          for (;;)
          {
            String line = inputReader.readLine();
            if ( line.equals( "" ))
                break;
            // System.out.println(line);
          }

          String[] tokens = requestLine.split(" ");
          String resource = tokens[1];

          File dir = new File("C:\\MyOwnServerFiles" );
          File file  = new File( dir, resource );
          if ( file.exists() && file.isDirectory())
            file = new File( file, "index.html");

          if ( ! file.exists())
          {
            System.out.println("File " +  file.getAbsolutePath() + " does not exist");
            // Send error
            outputWriter.println("HTTP/1.0 404 Not Found");
            outputWriter.println(); // The empty line
          } else
          {
            System.out.println("Sending file " + file.getAbsolutePath());

            // Send the success header

            outputWriter.println("HTTP/1.0 200 OK");
            outputWriter.println("Content-Type: text/html");
            outputWriter.println(); // The empty line

            // Send out the file
            FileInputStream in = new FileInputStream( file );
            int c;
            while (( c = in.read()) >= 0 )
              outputWriter.write( c );
            in.close();
          }
          outputWriter.close();
          inputStream.close();
          socket.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
