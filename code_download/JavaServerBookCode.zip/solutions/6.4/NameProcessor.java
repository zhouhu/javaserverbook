package myservlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class NameProcessor extends HttpServlet
{
  protected  void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException
  {
    String firstname = req.getParameter("firstname");
    String lastname = req.getParameter("lastname");

    if ( firstname == null || lastname == null )
    {
        resp.sendRedirect( "/EnterName.html" );
        return;
    }

    HttpSession session = req.getSession( true );

    session.setAttribute( "firstname", firstname );
    session.setAttribute( "lastname",  lastname );

    resp.sendRedirect( "/SessionTest" );
  }
}
