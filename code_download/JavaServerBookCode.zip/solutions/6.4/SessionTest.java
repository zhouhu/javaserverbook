package myservlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class SessionTest extends HttpServlet
{
  protected  void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException
  {
    HttpSession session = req.getSession( true );

    String firstname = (String) session.getAttribute("firstname");
    String lastname = (String) session.getAttribute("lastname");

    if ( firstname == null || lastname == null )
    {
      // Name is not in session, get via form

      resp.sendRedirect( "/EnterName.html" );
      return;
    }

    PrintWriter out = resp.getWriter();
    out.println( "<HTML>");
    out.println( "<BODY>");

    // Write out the first name and the last name

    out.println( "Hello " + firstname
                      + " " + lastname );

    out.println( "<P> The time is now ");
    out.println( new java.util.Date());
    out.println( "</BODY>");
    out.println( "</HTML>");
  }
}
