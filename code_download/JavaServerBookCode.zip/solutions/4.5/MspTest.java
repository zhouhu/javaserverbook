package test;

import java.io.*;
import java.util.*;
import mvows.*;

public class MspTest
{
  public static void main(String[] args) throws Exception
  {
    File mspFile = new File( "C:\\MyOwnServerFiles\\CurrentTime.msp");


     // Get a class for the MSP file using the MspProcessor, print the name of the loaded class

    MspProcessor mspProcessor = new MspProcessor();

    Class cls = mspProcessor.getMspClass( mspFile );
    System.out.println( cls.getName());

    // Reload the class, it should be the same without any rebuilds
    // You should not see the printout "Building MSP ..."

    Class cls1 = mspProcessor.getMspClass( mspFile );

    System.out.println( "cls1.equals(cls) returns " + cls1.equals(cls));

    // Touch the MSP file and get class again, this time it should rebuild

    mspFile.setLastModified( System.currentTimeMillis());
    Class cls2 = mspProcessor.getMspClass( mspFile );
    System.out.println("Retouched class (should rebuild): " + cls2.getName());

    Class cls3 = mspProcessor.getMspClass( mspFile );    
    System.out.println("Reloaded (should be without build)");

  }
}
