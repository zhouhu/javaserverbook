package test;

// A simple class for testing the class loader

public class TestClass
{
    public TestClass()
    {
        System.out.println( "Hello from TestClass" );
    }
}