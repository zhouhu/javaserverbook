package msp;

import java.io.*;
import java.util.*;
import mvows.*;

public class CurrentTime extends mvows.MyWeblet
{
  public void doRequest( String resource, String queryString,
    HashMap<String,String> parameters,
    PrintWriter out )
  {

    java.util.Date date = new java.util.Date();
    // toString() not required

    out.println( "" );
    out.println( "<HTML>" );
    out.println( "<BODY>" );
    out.print( "<P>The time is now " );
    out.print(  date );
    out.println( "" );
    out.println( "</BODY>" );
    out.println( "</HTML>" );
  }
}
