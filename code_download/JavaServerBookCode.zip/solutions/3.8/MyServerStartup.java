package myapps;

public class MyServerStartup implements mvows.ServerStartup {
    public void onServerStartup()
    {
        System.out.println("TBD: Server startup actions...");
    }
}
