package mvows;

import java.net.*;
import java.io.*;

public class Server
{
    static void callServerStartup()
    {
      for (String className: MyWebletConfigs.serverStartupClasses )
      {
        try {
          Class cls = Class.forName( className );
          ServerStartup serverStartupObject =
                (ServerStartup) cls.newInstance();
          // Call the startup method
          serverStartupObject.onServerStartup();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
      }
    }

    public static void main(String[] args) throws Exception
    {

        callServerStartup();

        System.setProperty("line.separator", "\r\n");
        new Thread( new SessionDeleter()).start();
        ServerSocket server = new ServerSocket( 80 );
        for (;;)
        {
            Socket socket = server.accept();
            new ServerInstance( socket ).start();
        }
    }
}
