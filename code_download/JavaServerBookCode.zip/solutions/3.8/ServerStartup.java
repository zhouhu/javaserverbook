package mvows;

public interface ServerStartup {
    void onServerStartup();
}