package myservlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class MyHelloWorld extends HttpServlet
{
  protected  void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException
  {
    PrintWriter out = resp.getWriter();
    out.println( "<HTML>");
    out.println( "<BODY>");
    out.println( "<H2>Hello, World</H2>" );
    out.println("Hello from My First Servlet");
    out.println( "</BODY>");
    out.println( "</HTML>");

  }  
}