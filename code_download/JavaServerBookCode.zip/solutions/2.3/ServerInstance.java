package mvows;

import java.net.*;
import java.io.*;

public class ServerInstance extends Thread
{

    Socket socket;

    public ServerInstance(Socket s)
    {
        socket = s;
    }

    public void run()
    {
        try {
          InputStream inputStream =
                  socket.getInputStream();
          BufferedReader inputReader =
            new BufferedReader(
               new InputStreamReader( inputStream ));
          OutputStream outputStream =
            socket.getOutputStream();
          PrintWriter outputWriter =
            new PrintWriter(
                new OutputStreamWriter( outputStream ));
          for (;;)
          {
            String line = inputReader.readLine();
            System.out.println( line );
            if ( line.equals( "" ))
                break;
          }
          // Now send the response
          outputWriter.println("HTTP/1.0 200 OK");
          outputWriter.println("Content-Type: text/html");
          outputWriter.println(); // The empty line
          outputWriter.println("<HTML>");

          outputWriter.println("<head>");
          outputWriter.println("<link rel=\"shortcut icon\" href=\"about:blank\" />");
          outputWriter.println("</head>");

          outputWriter.println("<BODY>");
          outputWriter.println("Hello from ");
          outputWriter.println("My Very Own ");
          outputWriter.println("Web Server");
          outputWriter.println("</BODY>");
          outputWriter.println("</HTML>");
          outputWriter.close();
          inputStream.close();
          socket.close();

        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
