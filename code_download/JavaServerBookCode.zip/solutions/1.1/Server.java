import java.net.*;
import java.io.*;

public class Server
{
    public static void main(String[] args) throws Exception
    {
        ServerSocket server = new ServerSocket( 1234 );
        System.out.println("Server created, waiting for client");
        Socket socket = server.accept();
        System.out.println("Client has connected");
	InputStream inputStream = socket.getInputStream();
	BufferedReader inputReader =
          new BufferedReader( new InputStreamReader( inputStream ));
	System.out.println("Client wrote: " + inputReader.readLine());

      OutputStream outputStream = socket.getOutputStream();
      PrintWriter outputWriter =
        new PrintWriter(
            new OutputStreamWriter( outputStream ));
      outputWriter.println("Hello from server");
      outputWriter.flush();

    }
}
