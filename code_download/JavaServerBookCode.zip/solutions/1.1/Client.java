import java.net.*;
import java.io.*;

public class Client
{
    public static void main(String[] args) throws Exception
    {
      Socket client = new Socket("localhost", 1234 );
      OutputStream outputStream = client.getOutputStream();
      PrintWriter outputWriter =
        new PrintWriter(
            new OutputStreamWriter( outputStream ));
      outputWriter.println("Hello from client");
      outputWriter.flush();

      InputStream inputStream = client.getInputStream();
      BufferedReader inputReader =
         new BufferedReader( new InputStreamReader( inputStream ));
      System.out.println("Server wrote: " + inputReader.readLine());

    }
}
