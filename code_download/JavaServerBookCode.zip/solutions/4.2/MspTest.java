package test;

import java.io.*;
import java.util.*;
import mvows.*;

public class MspTest
{
  public static void main(String[] args) throws Exception
  {
    File mspFile = new File( "CurrentTime.msp");

    // First of all, parse the MSP file
    List<MspPart> mspParts = 
          MspPart.parseMsp( mspFile );

    // Now create a Java file

    File javaFile = new File( mspFile.getAbsolutePath().replace( ".msp", ".java" ));
    String className = javaFile.getName().replace( ".java", "" );

    PrintWriter javaWriter = new PrintWriter( javaFile );

    javaWriter.println( "package msp;" );
    javaWriter.println();
    javaWriter.println( "import java.io.*;" );
    javaWriter.println( "import java.util.*;" );
    javaWriter.println( "import mvows.*;" );
    javaWriter.println();
    javaWriter.println( "public class " + className + " extends mvows.MyWeblet" );
    javaWriter.println( "{" );

    // Output all the declarations before starting 'doRequest'
    for ( MspPart part: mspParts )
    {
      switch ( part.partType )
      {
        case Declaration:
          javaWriter.println( part.partText );
	  break;
      }
    }

    javaWriter.println( "  public void doRequest( String resource, String queryString," );
    javaWriter.println( "    HashMap<String,String> parameters," );
    javaWriter.println( "    PrintWriter out )" );
    javaWriter.println( "  {" );

    // CODEGEN: This is where we output the code for doRequest.
    for ( MspPart part: mspParts )
    {
      switch ( part.partType )
      {
        case Text:
          javaWriter.println( "    out.print( \"" + part.partText + "\" );" );
	  break;
        case TextLine:
          javaWriter.println( "    out.println( \"" + part.partText + "\" );" );
          break;
        case Declaration:
          // NOt handled here
          break;
        case Expression:
          javaWriter.println( "    out.print( " + part.partText + ");" );
           // No double quotes this time
	  break;
        case Code:
          javaWriter.println( part.partText );
            // Just print it out
	  break;
      }
    }

    javaWriter.println( "  }" );
    javaWriter.println( "}" );

    javaWriter.close();
  }
}
