package mvowb;

// My very own web browser

import java.net.*;
import java.io.*;

public class Client
{
    public static void main(String[] args) throws Exception
    {
      System.setProperty("line.separator", "\r\n");  // For non-Windows system

      // Read host, resource and port from command window

      BufferedReader commandLineReader = new BufferedReader( new InputStreamReader( System.in ));
      System.out.print("Host (e.g. www.google.com): " );
      String host = commandLineReader.readLine();

      System.out.print("Port (usually 80 ): " );
      String str = commandLineReader.readLine().trim();
      int port = 80;
      if ( ! str.equals(""))
          port = Integer.parseInt( str );
      
      System.out.print("Resource (e.g. / ): " );
      String resource = commandLineReader.readLine();
      if ( ! resource.startsWith( "/" ))
          resource = "/" + resource;

      // Connect to the host on the specified port

      Socket client = new Socket( host, port );
      OutputStream outputStream = client.getOutputStream();
      PrintWriter outputWriter =
        new PrintWriter(
            new OutputStreamWriter( outputStream ));

      InputStream inputStream = client.getInputStream();

      // Open a debug text file

      OutputStream debugFile = new FileOutputStream( "C:\\MyOwnServerFiles\\MyDebugFile1.txt" );
            // TBD: Change the path appropriately!

      // Send request line
      outputWriter.println( "GET " + resource + " HTTP/1.0" );
      if ( port == 80 )
          outputWriter.println( "Host: " + host );
      else
          outputWriter.println( "Host: " + host + ":" + port);
      outputWriter.println("Connection: close");
      outputWriter.println();
      outputWriter.flush();
      int c;
      while (( c = inputStream.read()) >= 0 )
      {
          System.out.write( c );
          debugFile.write( c );
      }
      debugFile.close();
    }
}
