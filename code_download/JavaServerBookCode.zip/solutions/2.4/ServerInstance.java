package mvows;

import java.net.*;
import java.io.*;

public class ServerInstance extends Thread
{

    Socket socket;

    static int cookieNumber = 1;

    public ServerInstance(Socket s)
    {
        socket = s;
    }

    public void run()
    {
        try {
          // Get the input/output as usual
          InputStream inputStream =
                  socket.getInputStream();
          BufferedReader inputReader =
            new BufferedReader(
               new InputStreamReader( inputStream ));
          OutputStream outputStream =
            socket.getOutputStream();
          PrintWriter outputWriter =
            new PrintWriter(
                new OutputStreamWriter( outputStream ));
   
          boolean haveCookie = false;
          // Did browser send a cookie?

          for (;;)
          {
            // Read and print lines until empty line
            String line = inputReader.readLine();
            if ( line.equals( "" ))
                break;
            if ( line.startsWith( "Cookie: " ))
            {
              System.out.println("** Cookie Line **");
              System.out.println( line );
              haveCookie = true;
            }
            // System.out.println( line );
            // Avoid printing all lines so it is
            // easier see only the cookie line
          }
          // Now send the response
          outputWriter.println("HTTP/1.0 200 OK");
          outputWriter.println("Content-Type: text/html");
          if ( ! haveCookie )
          {
            String cookieValue = "cookie_" +
                         cookieNumber++;
            String cookieName = "MyVeryOwnCookie1";
            String cline = "Set-Cookie: " +
                 cookieName + ":" + cookieValue;
            outputWriter.println( cline );
            System.out.println("Sending cookie: "
                  + cline );
          }
          outputWriter.println(); // The empty line

          // Our usual HTML
          outputWriter.println("<HTML>");
          outputWriter.println("<head>");
          outputWriter.println(
            "<link rel=\"shortcut icon\" href=\"about:blank\" />");
          outputWriter.println("</head>");
          outputWriter.println("<BODY>");
          outputWriter.println("Hello from ");
          outputWriter.println("My Very Own Web Server");
          outputWriter.println("</BODY>");
          outputWriter.println("</HTML>");
          outputWriter.close();
          inputStream.close();
          socket.close();
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
