package mvows;

import java.util.*;

public class MyWebletSession {
    HashMap<String,Object> data = new HashMap<String,Object>();

    public void setAttribute( String key, Object value )
    {
        data.put( key, value );
    }

    public Object getAttribute( String key )
    {
        return data.get( key );
    }
}
