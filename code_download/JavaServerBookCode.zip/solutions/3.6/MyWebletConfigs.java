package mvows;

public class MyWebletConfigs
{
  String url;
  Class cls;

  public MyWebletConfigs( String url, Class cls )
  {
    this.url = url;
    this.cls = cls;
  }

  static MyWebletConfigs[] myWebletConfigs = new MyWebletConfigs[]
  {
    new MyWebletConfigs( "/ProcessName", myapps.NameProcessor.class ),
    new MyWebletConfigs( "/SessionTest", myapps.SessionTest.class ),
  };
}
