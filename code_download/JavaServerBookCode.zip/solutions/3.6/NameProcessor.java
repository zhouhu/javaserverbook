package myapps;

import java.io.*;
import java.util.*;
import mvows.*;

public class NameProcessor extends mvows.MyWeblet
{
    public void doRequest( String resource, String queryString,
                      HashMap<String,String> parameters,
                      PrintWriter out )
    {
        String firstname = parameters.get("firstname");
        String lastname = parameters.get("lastname");

        if ( firstname == null || lastname == null )
        {
            sendRedirect( "/EnterName.html" );
            return;
        }

        MyWebletSession session = getSession();

        session.setAttribute( "firstname", firstname );
        session.setAttribute( "lastname",  lastname );

        sendRedirect( "/SessionTest" );
    }
}
