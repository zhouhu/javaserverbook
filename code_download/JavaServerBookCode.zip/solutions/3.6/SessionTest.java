package myapps;

import java.io.*;
import java.util.*;
import mvows.*;

public class SessionTest extends mvows.MyWeblet
{
    public void doRequest( String resource, String queryString,
                           HashMap<String,String> parameters,
                           PrintWriter out )
    {
        MyWebletSession session = getSession();

        String firstname = (String) session.getAttribute("firstname");
        String lastname = (String) session.getAttribute("lastname");

        if ( firstname == null || lastname == null )
        {
            // Name is not in session, get via form

            sendRedirect( "/EnterName.html" );

            return;
        }

        out.println( "<HTML>");
        out.println( "<BODY>");

        // Write out the first name and the last name

        out.println( "Hello " + firstname
                          + " " + lastname );

        // Add some other dynamic info
        out.println( "<P> The time is now ");
        out.println( new java.util.Date());
        out.println( "<P>The Resource Name is " + resource );
        out.println( "<P>The Query String = " + queryString );
        out.println( "</BODY>");
        out.println( "</HTML>");
    }
}
