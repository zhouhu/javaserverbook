import java.net.*;
import java.io.*;

public class Server
{
    public static void main(String[] args) throws Exception
    {
        ServerSocket server = new ServerSocket( 1234 );
        for (;;)
        {
            System.out.println("Waiting for client connection");
            Socket socket = server.accept();
            System.out.println("Have client connection, launching thread");
            new ServerInstance( socket ).start();
        }
    }
}
