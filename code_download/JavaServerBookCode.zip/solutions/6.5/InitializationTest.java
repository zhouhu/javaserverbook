package myservlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class InitializationTest implements ServletContextListener
{
    public void	contextInitialized(ServletContextEvent sce)
    {
        System.out.println("*** INITIALIZATION OCCURRED ***");
             // Make it stand out among all console messages!
    }

    public void	contextDestroyed(ServletContextEvent sce)
    {
    }
}
