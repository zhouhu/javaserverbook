package myservlet;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class CookieTest extends HttpServlet
{
  static int cookieNumber = 1;
  static Object cookieLock = new Object();

  protected  void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException
  {
    PrintWriter out = resp.getWriter();
    out.println( "<HTML>");
    out.println( "<BODY>");

    // Check if the cookie exists
    Cookie cookie = null;
    Cookie[] cookies = req.getCookies(); // Returns all cookies
    if ( cookies != null )
    {
        for ( Cookie c: cookies )
        {
            if ( c.getName().equals("TestCookie"))
            {
                cookie = c;
                break;
            }
        }
    }

    // Set cookie if not found, print out cookie info
    // for verification

    if ( cookie == null )
    {
        // Give a unique cookie to each browser/visitor
        synchronized (cookieLock)
        {
            cookie = new Cookie( "TestCookie",
                 "Cookie_" + cookieNumber++ );
        }
        resp.addCookie(  cookie );
        out.println("Visiting browser did not have cookie");
        out.println("<P>Setting cookie to: " + cookie.getValue());
    } else {
        out.println("Browser has cookie: " + cookie.getValue());
    }

    // Add some other dynamic info
    out.println( "<P> The time is now ");
    out.println( new java.util.Date());
    out.println( "</BODY>");
    out.println( "</HTML>");
  }
}
