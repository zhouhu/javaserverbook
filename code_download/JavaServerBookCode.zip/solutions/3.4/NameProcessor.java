package myapps;

import java.io.*;
import java.util.*;

public class NameProcessor extends mvows.MyWeblet
{
    static int cookieNumber = 1;

    public void doRequest( String resource, String queryString,
                           HashMap<String,String> parameters,
                           PrintWriter out )
    {
        out.println( "<HTML>");
        out.println( "<BODY>");

        // Write out the first name and the last name

        out.println( "Hello " + parameters.get("firstname")
                  + " " + parameters.get("lastname"));

        // Check if the cookie exists
        String cookie = getRequestCookie( "TestCookie" );

        // Set cookie if not found, print out cookie info
        // to the Java console for verification

        if ( cookie == null )
        {
            // Give a unique cookie to each browser

            cookie = "Cookie_" + cookieNumber++ ;
            setResponseCookie( "TestCookie", cookie );
            System.out.println("Visiting browser does not have cookie");
            System.out.println("Setting cookie to: " + cookie );
        } else {
            System.out.println("Browser has cookie: " + cookie );
        }

        // Add some other dynamic info
        out.println( "<P> The time is now ");
        out.println( new java.util.Date());
        out.println( "<P>The Resource Name is " + resource );
        out.println( "<P>The Query String = " + queryString );
        out.println( "</BODY>");
        out.println( "</HTML>");
    }
}
